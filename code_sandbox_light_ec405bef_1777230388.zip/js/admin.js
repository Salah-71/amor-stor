/* ===== AMOR STOR - Admin JavaScript ===== */

// ===== Config =====
const ADMIN_PASSWORD = 'amor2025';
const WHATSAPP_NUMBER = '967775490941';

let allAdminProducts = [];
let deleteTargetId = null;
let isEditing = false;

// ===== LOGIN =====
function adminLogin(e) {
    e.preventDefault();
    const pass = document.getElementById('adminPass').value;
    if (pass === ADMIN_PASSWORD) {
        sessionStorage.setItem('amorAdmin', '1');
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'flex';
        loadAdminProducts();
        loadDashboardStats();
    } else {
        document.getElementById('loginError').textContent = '❌ كلمة المرور غير صحيحة';
        document.getElementById('adminPass').value = '';
    }
}

function adminLogout() {
    sessionStorage.removeItem('amorAdmin');
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('adminPanel').style.display = 'none';
    document.getElementById('adminPass').value = '';
    document.getElementById('loginError').textContent = '';
}

function togglePass() {
    const input = document.getElementById('adminPass');
    const icon = document.getElementById('eyeIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// Check if already logged in
document.addEventListener('DOMContentLoaded', () => {
    if (sessionStorage.getItem('amorAdmin') === '1') {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'flex';
        loadAdminProducts();
        loadDashboardStats();
    }
});

// ===== NAVIGATION =====
function showSection(sectionId, clickedEl) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById(`section-${sectionId}`).classList.add('active');

    // Update nav
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    if (clickedEl) clickedEl.classList.add('active');

    // Update topbar title
    const titles = {
        'dashboard': 'لوحة التحكم الرئيسية',
        'products': 'إدارة المنتجات',
        'add-product': isEditing ? 'تعديل المنتج' : 'إضافة منتج جديد'
    };
    document.getElementById('topbarTitle').textContent = titles[sectionId] || '';

    // Close mobile sidebar
    document.getElementById('sidebar').classList.remove('mobile-open');

    return false;
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('mobile-open');
}

// ===== LOAD PRODUCTS =====
async function loadAdminProducts() {
    const tbody = document.getElementById('productsTableBody');
    tbody.innerHTML = `<tr><td colspan="7" class="table-loading"><div class="spinner"></div> جاري التحميل...</td></tr>`;
    try {
        const res = await fetch('tables/products?limit=200&sort=created_at');
        const data = await res.json();
        allAdminProducts = data.data || [];
        renderAdminTable(allAdminProducts);
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="7" class="table-loading">❌ خطأ في التحميل. يرجى المحاولة مرة أخرى.</td></tr>`;
    }
}

function renderAdminTable(products) {
    const tbody = document.getElementById('productsTableBody');
    if (products.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><i class="fas fa-box-open"></i><h3>لا توجد منتجات</h3><p>أضف منتجك الأول الآن</p></div></td></tr>`;
        return;
    }
    tbody.innerHTML = products.map(p => {
        const price = Number(p.price || 0).toLocaleString('ar-YE');
        const isAvail = p.available !== false && p.available !== 'false';
        const isFeatured = p.featured === true || p.featured === 'true';
        const imgEl = p.image_url
            ? `<img src="${p.image_url}" alt="${escAdmin(p.name)}" class="table-img" onerror="this.outerHTML='<div class=\'table-img-placeholder\'>💄</div>'">`
            : `<div class="table-img-placeholder">💄</div>`;
        const desc = stripHtmlAdmin(p.description || '');
        const shortDesc = desc.length > 50 ? desc.substring(0, 50) + '...' : desc;
        return `
        <tr>
            <td>${imgEl}</td>
            <td>
                <div class="table-product-name">
                    ${escAdmin(p.name)}
                    <small>${escAdmin(shortDesc)}</small>
                </div>
            </td>
            <td><span class="badge normal">${escAdmin(p.category || '-')}</span></td>
            <td><strong style="color:var(--primary)">${price}</strong> <small>ريال</small></td>
            <td>
                <span class="badge ${isAvail ? 'available' : 'unavailable'}">
                    <i class="fas fa-circle" style="font-size:7px;"></i>
                    ${isAvail ? 'متاح' : 'غير متاح'}
                </span>
            </td>
            <td>
                <span class="badge ${isFeatured ? 'featured' : 'normal'}">
                    ${isFeatured ? '⭐ مميز' : 'عادي'}
                </span>
            </td>
            <td>
                <div class="table-actions">
                    <button class="tbl-btn edit" onclick="editProduct('${p.id}')" title="تعديل"><i class="fas fa-edit"></i></button>
                    <button class="tbl-btn whatsapp-share" onclick="shareProductWhatsApp('${p.id}')" title="مشاركة عبر واتساب"><i class="fab fa-whatsapp"></i></button>
                    <button class="tbl-btn delete" onclick="openDeleteModal('${p.id}')" title="حذف"><i class="fas fa-trash-alt"></i></button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

// ===== SEARCH =====
function adminSearchProducts() {
    const search = document.getElementById('adminSearchInput').value.toLowerCase();
    const cat = document.getElementById('adminCatFilter').value;
    const filtered = allAdminProducts.filter(p => {
        const matchSearch = !search || p.name.toLowerCase().includes(search) || (p.description || '').toLowerCase().includes(search);
        const matchCat = !cat || p.category === cat;
        return matchSearch && matchCat;
    });
    renderAdminTable(filtered);
}

// ===== DASHBOARD STATS =====
async function loadDashboardStats() {
    try {
        const res = await fetch('tables/products?limit=500');
        const data = await res.json();
        const products = data.data || [];
        document.getElementById('totalProducts').textContent = products.length;
        document.getElementById('featuredCount').textContent = products.filter(p => p.featured === true || p.featured === 'true').length;
        document.getElementById('availableCount').textContent = products.filter(p => p.available !== false && p.available !== 'false').length;
        const cats = new Set(products.map(p => p.category).filter(Boolean));
        document.getElementById('categoriesCount').textContent = cats.size;
    } catch (err) {
        console.error('Stats error:', err);
    }
}

// ===== SAVE PRODUCT (ADD / EDIT) =====
async function saveProduct(e) {
    e.preventDefault();
    const saveBtn = document.getElementById('saveBtn');
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<div class="spinner" style="width:18px;height:18px;border-width:2px;"></div> جاري الحفظ...';

    const editId = document.getElementById('editProductId').value;
    const productData = {
        name: document.getElementById('pName').value.trim(),
        category: document.getElementById('pCategory').value,
        price: parseFloat(document.getElementById('pPrice').value) || 0,
        description: document.getElementById('pDescription').value.trim(),
        image_url: document.getElementById('pImageUrl').value.trim(),
        available: document.getElementById('pAvailable').checked,
        featured: document.getElementById('pFeatured').checked
    };

    try {
        let res;
        if (editId) {
            res = await fetch(`tables/products/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
        } else {
            res = await fetch('tables/products', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
        }

        if (res.ok) {
            showAdminToast(editId ? '✅ تم تعديل المنتج بنجاح' : '✅ تم إضافة المنتج بنجاح', 'success');
            resetForm();
            await loadAdminProducts();
            await loadDashboardStats();
            showSection('products', document.querySelector('[data-section="products"]'));
        } else {
            const err = await res.json();
            showAdminToast('❌ خطأ: ' + (err.message || 'فشل الحفظ'), 'error');
        }
    } catch (err) {
        showAdminToast('❌ خطأ في الاتصال، يرجى المحاولة مرة أخرى', 'error');
    } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fas fa-save"></i> حفظ المنتج';
    }
}

// ===== EDIT PRODUCT =====
function editProduct(productId) {
    const p = allAdminProducts.find(x => x.id === productId);
    if (!p) return;
    isEditing = true;

    document.getElementById('editProductId').value = p.id;
    document.getElementById('pName').value = p.name || '';
    document.getElementById('pCategory').value = p.category || '';
    document.getElementById('pPrice').value = p.price || '';
    document.getElementById('pDescription').value = stripHtmlAdmin(p.description || '');
    document.getElementById('pImageUrl').value = p.image_url || '';
    document.getElementById('pAvailable').checked = p.available !== false && p.available !== 'false';
    document.getElementById('pFeatured').checked = p.featured === true || p.featured === 'true';

    previewImage();

    document.getElementById('formTitle').innerHTML = '<i class="fas fa-edit"></i> تعديل المنتج';
    document.getElementById('saveBtn').innerHTML = '<i class="fas fa-save"></i> حفظ التعديلات';

    showSection('add-product', document.querySelector('[data-section="add-product"]'));
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ===== RESET FORM =====
function resetForm() {
    isEditing = false;
    document.getElementById('productForm').reset();
    document.getElementById('editProductId').value = '';
    document.getElementById('pAvailable').checked = true;
    document.getElementById('pFeatured').checked = false;
    document.getElementById('formTitle').innerHTML = '<i class="fas fa-plus-circle"></i> إضافة منتج جديد';
    document.getElementById('saveBtn').innerHTML = '<i class="fas fa-save"></i> حفظ المنتج';
    document.getElementById('imagePreviewBox').innerHTML = `
        <div class="preview-placeholder">
            <i class="fas fa-image"></i>
            <span>معاينة الصورة</span>
        </div>`;
}

// ===== DELETE =====
function openDeleteModal(productId) {
    deleteTargetId = productId;
    document.getElementById('confirmModal').classList.add('active');
}

function closeConfirmModal() {
    deleteTargetId = null;
    document.getElementById('confirmModal').classList.remove('active');
}

async function confirmDelete() {
    if (!deleteTargetId) return;
    closeConfirmModal();
    try {
        const res = await fetch(`tables/products/${deleteTargetId}`, { method: 'DELETE' });
        if (res.ok || res.status === 204) {
            showAdminToast('🗑️ تم حذف المنتج بنجاح', 'success');
            await loadAdminProducts();
            await loadDashboardStats();
        } else {
            showAdminToast('❌ فشل حذف المنتج', 'error');
        }
    } catch (err) {
        showAdminToast('❌ خطأ في الاتصال', 'error');
    }
    deleteTargetId = null;
}

// ===== SHARE VIA WHATSAPP =====
function shareProductWhatsApp(productId) {
    const p = allAdminProducts.find(x => x.id === productId);
    if (!p) return;
    const price = Number(p.price || 0).toLocaleString('ar-YE');
    const msg = `🌸 *${p.name}*\n\n📦 الفئة: ${p.category || '-'}\n💰 السعر: ${price} ريال يمني صنعاء\n\n${stripHtmlAdmin(p.description || '').substring(0, 200)}\n\n✨ متجر AMOR STOR - متجر أدوات تجميل\n📱 للطلب: wa.me/${WHATSAPP_NUMBER}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
}

// ===== IMAGE PREVIEW =====
function previewImage() {
    const url = document.getElementById('pImageUrl').value.trim();
    const box = document.getElementById('imagePreviewBox');
    if (url) {
        box.innerHTML = `<img src="${url}" alt="معاينة" onerror="this.parentElement.innerHTML='<div class=\'preview-placeholder\'><i class=\'fas fa-exclamation-triangle\' style=\'color:var(--red)\'></i><span>رابط الصورة غير صالح</span></div>'" style="width:100%;height:100%;object-fit:contain;">`;
    } else {
        box.innerHTML = `
            <div class="preview-placeholder">
                <i class="fas fa-image"></i>
                <span>معاينة الصورة</span>
            </div>`;
    }
}

// ===== TOGGLE AVAILABILITY =====
async function toggleAvailability(productId, currentStatus) {
    try {
        await fetch(`tables/products/${productId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ available: !currentStatus })
        });
        await loadAdminProducts();
        showAdminToast('✅ تم تحديث الحالة', 'success');
    } catch (err) {
        showAdminToast('❌ خطأ في التحديث', 'error');
    }
}

// ===== TOAST =====
let adminToastTimer;
function showAdminToast(msg, type = 'success') {
    const toast = document.getElementById('adminToast');
    toast.textContent = msg;
    toast.className = `admin-toast show ${type}`;
    clearTimeout(adminToastTimer);
    adminToastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, 3500);
}

// ===== UTILITIES =====
function escAdmin(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function stripHtmlAdmin(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
}

// Close confirm modal on outside click
document.getElementById('confirmModal').addEventListener('click', function(e) {
    if (e.target === this) closeConfirmModal();
});
